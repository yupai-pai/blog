package com.tencent.cloud.tdmq.controller;

import com.tencent.cloud.tdmq.producer.MessageProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Description: 发送消息测试
 */
@RestController
public class TestController {

    @Autowired
    MessageProvider messageProvider;

    @GetMapping("/sendDirect")
    public String sendDirectMessage() {
        return messageProvider.sendToDirect();
    }

    @GetMapping("/sendFanout")
    public String sendFanoutMessage() {
        return messageProvider.sendToFanout();
    }

    @GetMapping("/sendTopic")
    public String sendTopicMessage() {
        return messageProvider.sendToTopic();
    }
}
