package com.tencent.cloud.tdmq.producer;

/**
 * 消息生产者接口
 */
public interface MessageProvider {

    /**
     * 发送消息到Direct交换机
     */
    String sendToDirect();

    /**
     * 发送消息到Fanout交换机
     */
    String sendToFanout();

    /**
     * 发送消息到Fanout交换机
     */
    String sendToTopic();
}
