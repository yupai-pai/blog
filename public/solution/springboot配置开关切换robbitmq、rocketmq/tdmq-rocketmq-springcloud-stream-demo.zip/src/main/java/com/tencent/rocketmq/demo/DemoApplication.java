package com.tencent.rocketmq.demo;

import com.tencent.rocketmq.demo.config.CustomChannelBinder;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;

/**
 * Description: RocketMqDemo
 */
@SpringBootApplication
@EnableBinding({CustomChannelBinder.class})
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

}
