package com.example.springbootstreamdemo.stream;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;
import org.springframework.stereotype.Component;

@EnableBinding({MqChannel.class})
public interface MqChannel {
    @Input("inputOne")
    SubscribableChannel inputOne();

    @Input("inputTwo")
    SubscribableChannel inputTwo();
}